package com.hostbuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostBuddyResTapiCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostBuddyResTapiCrudApplication.class, args);
	}

}
