package com.hostbuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostBuddyResTapiCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
